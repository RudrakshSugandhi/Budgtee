package com.rudrakshsugandhi.budgtee;

import android.app.DatePickerDialog;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.provider.Settings;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;

public class CreditActivity extends AppCompatActivity {
    Button b1;
    mysql mydb;
    Calendar mCurrentDate;
    int day,month,year;
    EditText ed2, ed3;
    TextView tv;
public static int amt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_credit);
        b1 = (Button) findViewById(R.id.button2);
        ed2 = (EditText) findViewById(R.id.editText3);
       tv=(TextView)findViewById(R.id.textView);
      /*  mCurrentDate = Calendar.getInstance();
        day = mCurrentDate.get(Calendar.DAY_OF_MONTH);
        month = mCurrentDate.get(Calendar.MONTH);
        year = mCurrentDate.get(Calendar.YEAR);
        month = month+1;*/
        ed3.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {

            }

        });
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                amt=Integer.parseInt(ed2.getText().toString());
                SharedPreferences pref=getSharedPreferences("pre",0);
                SharedPreferences.Editor editor=pref.edit();
                editor.putInt("amt",amt);
                editor.commit();
                Toast.makeText(CreditActivity.this,"Information Submitted",Toast.LENGTH_SHORT).show();
            }
        });




    }


}

