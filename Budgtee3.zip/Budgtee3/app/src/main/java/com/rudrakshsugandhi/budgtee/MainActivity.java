package com.rudrakshsugandhi.budgtee;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.ImageReader;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Html;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.github.clans.fab.FloatingActionButton;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;

public class MainActivity extends AppCompatActivity {
    private FloatingActionButton mFAB,mf;
  TextView tv1;
Button b,bu;
ImageView ivGalImg;
Bitmap bmp;
int balance=0,b1,b2;
String stg;


    public void AddExpense(View v) {
        Intent startNewActivity = new Intent(this, AddExpensesActivity.class);
        startActivity(startNewActivity);
    }
    public void ViewButton(View v) {
        Intent startNewActivity = new Intent(this, ViewActivity.class);
        startActivity(startNewActivity);
    }
    public void CreditButton(View v) {
        Intent startNewActivity = new Intent(this, CreditActivity.class);
        startActivity(startNewActivity);
    }
//SharedPreferences pres=getSharedPreferences("My_pref",MODE_PRIVATE);
 //   SharedPreferences.Editor editor=pres.edit();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
bu=(Button)findViewById(R.id.button5);
b=(Button)findViewById(R.id.button4);
ivGalImg=(ImageView)findViewById(R.id.img);
tv1=(TextView)findViewById(R.id.textView);
tv1.setText("Balance :\n ");


     bu.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View v) {
             Intent i=new Intent(Intent.ACTION_PICK,MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
           //  i.setType("image/*");

              startActivityForResult(i,1);



         }
     });

       b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              //  editor.putInt("amt",CreditActivity.amt);
             //   editor.putInt("sum",ViewActivity.sum);
              //  balance = pres.getInt("amt",0)-pres.getInt("sum",0);
                SharedPreferences pre=getSharedPreferences("pre",0);
                b1=pre.getInt("amt",0);

                b2=pre.getInt("sum",0);
balance=b1-b2;

                    tv1.setText("Balance : \n" +"Rs "+ balance);
                SharedPreferences p=getSharedPreferences("p",0);
                stg=p.getString("img",null);
                byte[] imageasbyte=Base64.decode(stg.getBytes(),Base64.DEFAULT);
                ivGalImg.setImageBitmap(BitmapFactory.decodeByteArray(imageasbyte,0,imageasbyte.length));
              //  editor.putInt("amt",CreditActivity.amt);
              //  editor.putInt("sum",ViewActivity.sum);
            }




       });

       // tv=(TextView)findViewById(R.id.textView);
      
       /* mFAB = (FloatingActionButton) findViewById(R.id.menu_item);
        mFAB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Clicked", Toast.LENGTH_SHORT).show();



            }

        });*/

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==1){
            if(data!=null && resultCode==RESULT_OK){
                Uri selectedImage=data.getData();
                String[] filePathColumn={MediaStore.Images.Media.DATA};
                Cursor cursor=getContentResolver().query(selectedImage,filePathColumn,null,null,null);
                cursor.moveToFirst();
                int columnIndex=cursor.getColumnIndex(filePathColumn[0]);
                String filePath=cursor.getString(columnIndex);
                cursor.close();
                if(bmp!=null && !bmp.isRecycled())
                {
                    bmp=null;
                }
               // bmp=BitmapFactory.decodeFile(filePath);
                try {
                    bmp = MediaStore.Images.Media.getBitmap(getContentResolver(), selectedImage);
                    // ivGalImg.setBackgroundResource(0);
                    ivGalImg.setImageBitmap(bmp);
                 // URI=Uri.parse()
                    ByteArrayOutputStream stream=new ByteArrayOutputStream();
                    bmp.compress(Bitmap.CompressFormat.PNG,90,stream);
                    byte[] image=stream.toByteArray();
                    String img_str=Base64.encodeToString(image,0);
                    SharedPreferences pref=getSharedPreferences("p",0);
                    SharedPreferences.Editor editor=pref.edit();
                    editor.putString("img",img_str);
                    editor.commit();
                }catch(IOException e){
                   e.printStackTrace();
                }

            }
            else
            {
                Log.d("Status:","Photopicker cancled");

            }
        }
    }
}
