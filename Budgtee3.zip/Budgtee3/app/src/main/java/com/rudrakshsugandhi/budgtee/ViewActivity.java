package com.rudrakshsugandhi.budgtee;

import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabaseCorruptException;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.nio.Buffer;
import java.util.Calendar;


public class ViewActivity extends AppCompatActivity  {
    mysql mydb;
    SQLiteDatabase db1;
    Calendar mCurrentDate;
    int day,month,year;
    public final int requestcode=0;
    public static  Integer sum,summation;
    Button b2,b3,b4,b5;
    EditText ed,ed2;
    TextView tv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view);

        b2 = (Button) findViewById(R.id.button3);
        b4=(Button)findViewById(R.id.Button4);
       b3=(Button)findViewById(R.id.button_delete);

       ed=(EditText)findViewById(R.id.EditText6);
       ed2=(EditText)findViewById(R.id.EditText7);


        mydb = new mysql(this);
        mCurrentDate = Calendar.getInstance();
        day = mCurrentDate.get(Calendar.DAY_OF_MONTH);
        month = mCurrentDate.get(Calendar.MONTH);
        year = mCurrentDate.get(Calendar.YEAR);
        month = month+1;
        ed2.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                DatePickerDialog datePickerDialog = new DatePickerDialog(ViewActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthofYear, int dayOfMonth) {
                        monthofYear = monthofYear +1;
                        ed2.setText(dayOfMonth+"/"+monthofYear+"/"+year);

                    }
                },year,month,day);
                datePickerDialog.show();
            }

        });
        viewAll();
       DeleteData();
      vall();


      /*  b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                StringBuffer finalData =new StringBuffer();
               Cursor cursor = mydb.getAllRecord();

                for(cursor.moveToFirst(); !cursor.moveToLast(); cursor.moveToNext())
                {
                    finalData.append(cursor.getInt(cursor.getColumnIndex(mydb.ID)));
                    finalData.append(" - ");
                    finalData.append(cursor.getInt(cursor.getColumnIndex(mydb.COL_2)));
                    finalData.append(" - ");
                    finalData.append(cursor.getInt(cursor.getColumnIndex(mydb.COl_3)));
                    finalData.append(" - ");
                    finalData.append(cursor.getInt(cursor.getColumnIndex(mydb.COL_4)));
                    finalData.append(" \n ");

                }
                tv.setText(finalData);
            }
        });*/
    }


    public void vall(){
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //sum=mydb.getaddition();
                sum=0;
                Cursor res = mydb.getAllData();
                if(res.getCount() == 0){
                    //show message
                    showMessage("Error","Nothing found");
                    return;
                }

                // int sum=0;


                StringBuffer buffer = new StringBuffer();
                while(res.moveToNext())
                {
                     //  buffer.append("Date   ID  MONEY   CATEGORY"+"\n");
                     //  buffer.append(res.getString(3)+"  "+res.getString(0)+"  "+res.getString(1)+"  "+res.getString(2)+"\n");
                        buffer.append("Date:"+res.getString(3)+ "\n");
                        buffer.append("ID :" + res.getString(0) + "\n");
                        buffer.append("MONEY :" + res.getInt(1) + "\n");
                        buffer.append("CATEGORY :" + res.getString(2) + "\n\n");
                       sum = sum +res.getInt(res.getColumnIndex("MONEY"));


                    //   buffer.append("DATE :" +res.getString(3)+"\n\n");

                    //check here if error
                }

                //show all data
                buffer.append("\n\n\n");
               buffer.append("TOTAL SUM IS: "+sum +" Rs");
                showMessage("Data",buffer.toString());
                SharedPreferences pref=getSharedPreferences("pre",0);
                SharedPreferences.Editor editor=pref.edit();
                editor.putInt("sum",sum);
                editor.commit();
             //   getApplicationContext().startService(i);

                //  tv.setText(sum);

            }

        });

    }



    public void viewAll()
    {
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                summation=0;

                mydb.getAllData();

                Cursor res = mydb.getAllData();
                if(res.getCount() == 0){
                    //show message
                    showMessage("Error","Nothing found");
                    return;
                }

                StringBuffer buffer = new StringBuffer();
                while(res.moveToNext())
                {
                    if(res.getString(3).equals(ed2.getText().toString())) {
                        buffer.append("ID :" + res.getString(0) + "\n");
                        buffer.append("MONEY :" + res.getInt(1) + "\n");

                        buffer.append("CATEGORY :" + res.getString(2) + "\n\n");
                        summation=summation+res.getInt(res.getColumnIndex("MONEY"));
                    }
                 //   buffer.append("DATE :" +res.getString(3)+"\n\n");

                  //check here if error
                }
                //show all data
                buffer.append("\n\n\n");
                buffer.append("Total Exenditure on "+ed2.getText().toString()+" is:"+summation+" Rs");
                showMessage("Data",buffer.toString());
            }
        });

    }

    public void showMessage(String title,String Message)
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(Message);
        builder.show();

    }
    public void DeleteData(){

       b3.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               boolean isdelete = mydb.DeleteData(ed.getText().toString());
               if(isdelete == true)
                   Toast.makeText(ViewActivity.this,"Data Deleted successfully",Toast.LENGTH_LONG).show();

               else
                   Toast.makeText(ViewActivity.this,"Data not Deleted",Toast.LENGTH_LONG).show();
           }
       });
    }


}
